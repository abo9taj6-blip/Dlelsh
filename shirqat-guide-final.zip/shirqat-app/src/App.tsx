/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ShoppingBag, 
  Utensils, 
  Zap, 
  Sprout, 
  PlusCircle, 
  Phone, 
  MessageCircle, 
  WifiOff,
  Search,
  Menu,
  Bell,
  X,
  Info,
  ShieldCheck,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  ChevronRight,
  ArrowRight,
  Stethoscope,
  Car,
  Tag,
  Clock,
  Cloud,
  Sun,
  CloudRain,
  UserRound,
  Home,
  Lock,
  LogOut,
  Download,
  Upload,
  Send,
  Trash2,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { getPrayerTimes } from './services/api';
import { DataStorage } from './services/localDataService';
import { useOfflineSync } from './hooks/useOfflineSync';

// --- Components ---
const PrayerTimesWidget = () => {
  const [times, setTimes] = useState<any>(null);
  const [nextPrayerIndex, setNextPrayerIndex] = useState(-1);

  useEffect(() => {
    getPrayerTimes().then(data => {
      setTimes(data);
      if (data) {
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        
        const prayerList = [
          { name: 'Fajr', time: data.Fajr },
          { name: 'Dhuhr', time: data.Dhuhr },
          { name: 'Asr', time: data.Asr },
          { name: 'Maghrib', time: data.Maghrib },
          { name: 'Isha', time: data.Isha },
        ];

        let nextIdx = prayerList.findIndex(p => {
          const [h, m] = p.time.split(':').map(Number);
          return (h * 60 + m) > currentTime;
        });

        if (nextIdx === -1) nextIdx = 0; // Next is Fajr tomorrow
        setNextPrayerIndex(nextIdx);
      }
    });
  }, []);

  if (!times) return null;

  const formatTime12 = (time24: string) => {
    if (!time24) return '';
    const [hours, minutes] = time24.split(':').map(Number);
    const period = hours >= 12 ? 'مساءً' : 'صباحاً';
    const hours12 = hours % 12 || 12;
    return `${hours12}:${minutes.toString().padStart(2, '0')} ${period}`;
  };

  const prayers = [
    { name: 'الفجر', time: times.Fajr, icon: '🌅' },
    { name: 'الظهر', time: times.Dhuhr, icon: '☀️' },
    { name: 'العصر', time: times.Asr, icon: '🌤️' },
    { name: 'المغرب', time: times.Maghrib, icon: '🌇' },
    { name: 'العشاء', time: times.Isha, icon: '🌙' },
  ];

  return (
    <div className="bg-gradient-to-br from-shirqat-primary via-sky-600 to-sky-800 p-5 rounded-[2.5rem] shadow-2xl shadow-shirqat-primary/30 overflow-hidden relative border border-white/20">
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1] 
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-0 right-0 w-48 h-48 bg-white rounded-full -mr-20 -mt-20 blur-3xl"
      ></motion.div>
      
      <div className="flex items-center justify-between mb-5 relative z-10">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-2.5 rounded-2xl backdrop-blur-md border border-white/30 shadow-inner">
            <Clock size={20} className="text-white" />
          </div>
          <div>
            <p className="text-sm text-white font-black tracking-tight">مواقيت الصلاة</p>
            <p className="text-[10px] text-sky-100/80 font-medium">الشرقاط، صلاح الدين</p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-white/90 bg-black/20 px-3 py-1.5 rounded-full backdrop-blur-md border border-white/10 font-bold">
            {new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' })}
          </span>
        </div>
      </div>
      
      <div className="grid grid-cols-5 gap-2.5 relative z-10">
        {prayers.map((p, idx) => {
          const isNext = idx === nextPrayerIndex;
          return (
            <motion.div 
              key={p.name}
              initial={false}
              animate={isNext ? { y: -4, scale: 1.05 } : { y: 0, scale: 1 }}
              className={`relative p-2.5 rounded-2xl flex flex-col items-center transition-all duration-500 border ${
                isNext 
                  ? 'bg-white shadow-xl border-white' 
                  : 'bg-white/10 backdrop-blur-md border-white/10 hover:bg-white/15'
              }`}
            >
              {isNext && (
                <motion.div 
                  layoutId="active-glow"
                  className="absolute inset-0 bg-shirqat-primary/20 blur-xl rounded-2xl -z-10"
                />
              )}
              <span className={`text-xl mb-1.5 ${isNext ? 'scale-110' : 'opacity-80'}`}>{p.icon}</span>
              <span className={`text-[10px] mb-1 font-bold ${isNext ? 'text-shirqat-primary' : 'text-sky-100'}`}>{p.name}</span>
              <span className={`text-[9px] font-black whitespace-nowrap ${isNext ? 'text-slate-900' : 'text-white'}`}>{formatTime12(p.time)}</span>
              
              {isNext && (
                <div className="absolute -bottom-1 w-1 h-1 bg-shirqat-primary rounded-full" />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
interface SocialLinks {
  facebook?: string;
  instagram?: string;
  whatsapp?: string;
}

interface Offer {
  id: string;
  title: string;
  shopName: string;
  category: string;
  description: string;
  location: string;
  oldPrice?: string;
  newPrice?: string;
  expiryDate?: string;
  phone1: string;
  phone2?: string;
  social?: SocialLinks;
  image: string;
  isRestaurant?: boolean;
  isVerified?: boolean;
  hours?: string;
  menu?: MenuItem[];
}

interface BannerAd {
  id: string;
  image: string;
  type: 'internal' | 'text';
  // For internal
  targetId?: string;
  targetType?: 'offer' | 'doctor' | 'taxi';
  // For text
  title?: string;
  content?: string;
  buttonText?: string;
  url?: string; // External link for text content button
}

interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
}

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  description: string;
  location: string;
  phone1: string;
  phone2?: string;
  hours: string;
  image?: string;
  isVerified?: boolean;
}

interface Taxi {
  id: string;
  name: string;
  description: string;
  phone1: string;
  phone2?: string;
  carType: string;
  location: string;
  image?: string;
  hours?: string;
  isVerified?: boolean;
}

interface MenuItem {
  name: string;
  price: string;
  description?: string;
}

const CATEGORIES = [
  { id: 'all', name: 'الكل', icon: <ShoppingBag size={18} /> },
  { id: 'food', name: 'مواد غذائية', icon: <Utensils size={18} /> },
  { id: 'clothes', name: 'ملابس', icon: <ShoppingBag size={18} /> },
  { id: 'electronics', name: 'أجهزة كهربائية', icon: <Zap size={18} /> },
  { id: 'agri', name: 'أدوات زراعية', icon: <Sprout size={18} /> },
  { id: 'pharma', name: 'صيدليات', icon: <PlusCircle size={18} /> },
];

const MOCK_OFFERS: Offer[] = [
  {
    id: '1',
    title: 'عرض السلة الغذائية المتكاملة - 12,500 د.ع',
    shopName: 'أسواق البركة',
    category: 'food',
    isVerified: true,
    description: 'كيس رز بسمتي 5 كيلو درجة أولى + زيت نباتي 1 لتر مجاناً + معجون طماطم. العرض ساري حتى نفاذ الكمية.',
    location: 'الشرقاط - حي العسكري - قرب جامع الرحمن',
    oldPrice: '15,000',
    newPrice: '12,500',
    expiryDate: '2024-03-20',
    phone1: '07701234567',
    phone2: '07801234567',
    social: { facebook: 'https://facebook.com', whatsapp: '9647701234567' },
    image: 'https://picsum.photos/seed/food1/400/300',
  },
  {
    id: '2',
    title: 'تنزيلات الشتاء الكبرى - 68,000 د.ع',
    shopName: 'معرض الشرقاط للكهربائيات',
    category: 'electronics',
    isVerified: false,
    description: 'تنزيلات حقيقية تصل إلى 20% على جميع أنواع السخانات والمدافئ الكهربائية والنفطية بضمان حقيقي لمدة سنة.',
    location: 'الشرقاط - السوق العام - مقابل عمارة البلدية',
    oldPrice: '85,000',
    newPrice: '68,000',
    expiryDate: '2024-03-15',
    phone1: '07701112223',
    social: { facebook: 'https://facebook.com', whatsapp: '9647701112223' },
    image: 'https://picsum.photos/seed/elec1/400/300',
  },
  {
    id: '3',
    title: 'مكتبة النور - قرطاسية ومستلزمات مدرسية',
    shopName: 'مكتبة النور',
    category: 'electronics',
    isVerified: false,
    description: 'تجهيز كافة المستلزمات المدرسية والقرطاسية بأسعار الجملة. تتوفر لدينا خدمة الاستنساخ والطباعة الملونة.',
    location: 'الشرقاط - شارع الأطباء - قرب مجمع الشفاء',
    phone1: '07703334445',
    social: { whatsapp: '9647703334445' },
    image: 'https://picsum.photos/seed/library/400/300'
  },
  {
    id: '4',
    title: 'مطعم الزيتون - وجبات سريعة ومشويات',
    shopName: 'مطعم الزيتون',
    category: 'food',
    isRestaurant: true,
    isVerified: false,
    description: 'أشهى المأكولات الشرقية والغربية. نتميز بالمشويات العراقية الأصيلة والبرجر العملاق.',
    location: 'الشرقاط - مدخل المدينة - قرب السيطرة',
    phone1: '07704445556',
    hours: '10:00 صباحاً - 12:00 ليلاً',
    image: 'https://picsum.photos/seed/rest3/400/300',
    menu: [
      { name: 'كباب عراقي', price: '10,000 د.ع' },
      { name: 'برجر لحم خاص', price: '6,000 د.ع' },
      { name: 'دجاج شواية', price: '12,000 د.ع' }
    ]
  },
  {
    id: '5',
    title: 'محل الأناقة الرجالية - ملابس شبابية',
    shopName: 'الأناقة الرجالية',
    category: 'clothes',
    isVerified: false,
    description: 'أحدث موديلات الملابس الرجالية والشبابية. ماركات تركية وعالمية بأسعار مناسبة جداً.',
    location: 'الشرقاط - السوق العام',
    phone1: '07705556667',
    social: { instagram: 'https://instagram.com' },
    image: 'https://picsum.photos/seed/fashion/400/300'
  },
  {
    id: '6',
    title: 'صيدلية الرافدين - كافة المستلزمات الطبية',
    shopName: 'صيدلية الرافدين',
    category: 'pharma',
    isVerified: false,
    description: 'توفير كافة الأدوية والمستلزمات الطبية وحليب الأطفال. خدمة قياس الضغط والسكر متوفرة دائماً.',
    location: 'الشرقاط - قرب المستشفى العام',
    phone1: '07706667778',
    image: 'https://picsum.photos/seed/pharma2/400/300'
  }
];

const BANNER_ADS: BannerAd[] = [
  { id: 'b1', image: 'https://picsum.photos/seed/ad1/800/400', type: 'internal', targetId: '1', targetType: 'offer' },
  { id: 'b2', image: 'https://picsum.photos/seed/ad2/800/400', type: 'text', title: 'مرحباً بكم في دليل الشرقاط', content: 'دليلك الشامل لكل ما تحتاجه في المدينة من أطباء ومحلات وسواق تكسي.', buttonText: 'تواصل معنا', url: 'https://wa.me/9647740100909' },
  { id: 'b3', image: 'https://picsum.photos/seed/ad3/800/400', type: 'text', title: 'إعلان هام لأهالي الشرقاط', content: 'نود إعلامكم بأن التطبيق سيخضع لتحديثات دورية لتحسين الخدمة. شكراً لثقتكم بنا.', buttonText: 'فهمت ذلك' },
];

const MOCK_DOCTORS: Doctor[] = [
  {
    id: 'd1',
    name: 'د. أحمد الجبوري',
    specialty: 'أخصائي باطنية وقلبية',
    isVerified: true,
    description: 'خبرة أكثر من 15 عاماً في علاج أمراض القلب والشرايين والضغط والسكري. تتوفر في العيادة أجهزة تخطيط القلب والسونار المتقدم.',
    location: 'الشرقاط - شارع الأطباء - مجمع الشفاء الطبي',
    phone1: '07701112223',
    phone2: '07801112223',
    hours: '4:00 مساءً - 9:00 مساءً',
    image: 'https://picsum.photos/seed/doc1/200/200'
  },
  {
    id: 'd2',
    name: 'د. سارة العبيدي',
    specialty: 'أخصائية نسائية وتوليد',
    isVerified: false,
    description: 'متابعة الحمل والولادة، علاج حالات العقم، جراحة النسائية والتوليد. العيادة مجهزة بأحدث أجهزة السونار الملون.',
    location: 'الشرقاط - قرب المستشفى العام',
    phone1: '07704445556',
    hours: '9:00 صباحاً - 2:00 مساءً',
    image: 'https://picsum.photos/seed/doc2/200/200'
  },
  {
    id: 'd3',
    name: 'د. علي السامرائي',
    specialty: 'أخصائي طب وجراحة العيون',
    isVerified: false,
    description: 'فحص البصر بالكمبيوتر، عمليات سحب الماء الأبيض، علاج أمراض الشبكية والقرطاسية.',
    location: 'الشرقاط - حي العسكري - مجمع النور الطبي',
    phone1: '07705556667',
    hours: '3:00 مساءً - 8:00 مساءً',
    image: 'https://picsum.photos/seed/doc3/200/200'
  }
];

const MOCK_TAXIS: Taxi[] = [
  {
    id: 't1',
    name: 'تكسي الأمان',
    isVerified: true,
    description: 'خدمة تكسي داخل وخارج القضاء على مدار 24 ساعة. سيارات حديثة ومكيفة مع سواق ذوي خبرة وأمانة عالية.',
    phone1: '07709998887',
    phone2: '07809998887',
    carType: 'سايبا - بيضاء',
    location: 'الشرقاط - كراج بغداد',
    image: 'https://picsum.photos/seed/taxi1/200/200',
    hours: 'على مدار 24 ساعة'
  },
  {
    id: 't2',
    name: 'تكسي الفرسان',
    isVerified: false,
    description: 'توصيل طلبات، مشاوير داخلية، وسفرات للمحافظات. نتميز بالسرعة والدقة في المواعيد.',
    phone1: '07707776665',
    carType: 'إلنترا - صفراء',
    location: 'الشرقاط - السوق العام',
    image: 'https://picsum.photos/seed/taxi2/200/200'
  },
  {
    id: 't3',
    name: 'تكسي النجوم',
    isVerified: false,
    description: 'خدمة توصيل متميزة بأسعار تنافسية. متواجدون في حي العسكري لخدمتكم في أي وقت.',
    phone1: '07705554443',
    phone2: '07505554443',
    carType: 'أوبتيما - صفراء',
    location: 'الشرقاط - حي العسكري',
    image: 'https://picsum.photos/seed/taxi3/200/200'
  }
];

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeCategory, setActiveCategory] = useState('all');
  const [currentTab, setCurrentTab] = useState<'home' | 'offers' | 'doctors' | 'taxi'>('home');
  const [sidebarPage, setSidebarPage] = useState<'about' | 'privacy' | 'contact' | 'admin' | null>(null);
  const { isOffline, isSyncing, justSynced, lastSync, syncNow } = useOfflineSync();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedTaxi, setSelectedTaxi] = useState<Taxi | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdModal, setShowAdModal] = useState(false);
  const [currentBanner, setCurrentBanner] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem('shirqat_notifications');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error parsing notifications from localStorage', e);
      }
    }
    return [
      {
        id: '1',
        title: 'مرحباً بك في دليل الشرقاط',
        message: 'نسخة تجريبية جديدة من التطبيق، نتمنى أن تنال إعجابكم.',
        time: 'منذ ساعة'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('shirqat_notifications', JSON.stringify(notifications));
  }, [notifications]);

  const [activePopupNotification, setActivePopupNotification] = useState<AppNotification | null>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const bellRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        showNotifications &&
        notificationsRef.current &&
        !notificationsRef.current.contains(event.target as Node) &&
        bellRef.current &&
        !bellRef.current.contains(event.target as Node)
      ) {
        setShowNotifications(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showNotifications]);

  const unreadCount = notifications.length;

  const handleNotificationClick = (id: string) => {
    // Remove the notification from the list since they are temporary
    setNotifications(prev => prev.filter(n => n.id !== id));
    setShowNotifications(false);
  };

  const markAllAsRead = () => {
    // Clear all notifications since they are temporary
    setNotifications([]);
    setShowNotifications(false);
  };
  
  // Admin & Data State
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginPassword, setLoginPassword] = useState('');
  const [offers, setOffers] = useState<Offer[]>(() => DataStorage.getOffers(MOCK_OFFERS));
  const [doctors, setDoctors] = useState<Doctor[]>(() => DataStorage.getDoctors(MOCK_DOCTORS));
  const [taxis, setTaxis] = useState<Taxi[]>(() => DataStorage.getTaxis(MOCK_TAXIS));
  const [banners, setBanners] = useState<BannerAd[]>(() => DataStorage.getBanners(BANNER_ADS));
  const [selectedBannerText, setSelectedBannerText] = useState<BannerAd | null>(null);
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({});
  const [adminView, setAdminView] = useState<'main' | 'offers' | 'doctors' | 'taxis'>('main');
  const [editingItem, setEditingItem] = useState<any>(null);

  const toggleMenu = (id: string) => {
    setExpandedMenus(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleLogin = () => {
    if (loginPassword === 'admin123') {
      setIsAdmin(true);
      setShowLoginModal(false);
      setLoginPassword('');
    } else {
      alert('كلمة المرور غير صحيحة');
    }
  };

  const handleLogout = () => {
    setIsAdmin(false);
    setCurrentTab('home');
  };

  const exportData = () => {
    const data = { offers, doctors, taxis, notifications };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shirqat_data_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          const data = JSON.parse(content);
          if (data.offers) setOffers(data.offers);
          if (data.doctors) setDoctors(data.doctors);
          if (data.taxis) setTaxis(data.taxis);
          if (data.notifications) setNotifications(data.notifications);
          alert('تم استيراد البيانات بنجاح');
        } catch (err) {
          alert('خطأ في تنسيق الملف');
        }
      };
      reader.readAsText(file);
    }
  };

  const sendNotification = (title: string, message: string) => {
    const newNotif: AppNotification = {
      id: Date.now().toString(),
      title,
      message,
      time: 'الآن'
    };
    setNotifications(prev => [newNotif, ...prev]);
    setActivePopupNotification(newNotif);
    setTimeout(() => {
      setActivePopupNotification(null);
    }, 5000);
  };

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2000);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then(reg => {
        reg.addEventListener('updatefound', () => {
          const nw = reg.installing;
          nw?.addEventListener('statechange', () => {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) {
              console.log('[SW] تحديث جديد متاح');
            }
          });
        });
      }).catch(err => console.warn('[SW] Registration failed', err));
    }

    return () => clearTimeout(timer);
  }, []);

  // حفظ البيانات تلقائياً في localStorage عند كل تغيير
  useEffect(() => { DataStorage.saveOffers(offers);   }, [offers]);
  useEffect(() => { DataStorage.saveDoctors(doctors); }, [doctors]);
  useEffect(() => { DataStorage.saveTaxis(taxis);     }, [taxis]);
  useEffect(() => { DataStorage.saveBanners(banners); }, [banners]);

  useEffect(() => {
    if (banners.length === 0) return;
    
    // Ensure current banner is within bounds if banners list changes
    if (currentBanner >= banners.length) {
      setCurrentBanner(0);
    }

    const bannerTimer = setInterval(() => {
      setCurrentBanner(prev => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(bannerTimer);
  }, [banners.length, currentBanner]);

  const filteredOffers = offers.filter(o => 
    o.title.includes(searchQuery) || o.shopName.includes(searchQuery)
  ).sort((a, b) => (b.isVerified ? 1 : 0) - (a.isVerified ? 1 : 0));

  const filteredDoctors = doctors.filter(d => 
    d.name.includes(searchQuery) || d.specialty.includes(searchQuery)
  ).sort((a, b) => (b.isVerified ? 1 : 0) - (a.isVerified ? 1 : 0));

  const filteredTaxis = taxis.filter(t => 
    t.name.includes(searchQuery) || t.carType.includes(searchQuery) || t.location.includes(searchQuery)
  ).sort((a, b) => (b.isVerified ? 1 : 0) - (a.isVerified ? 1 : 0));

  const handleBannerClick = (ad: BannerAd) => {
    if (ad.type === 'internal' && ad.targetId && ad.targetType) {
      if (ad.targetType === 'offer') {
        const item = offers.find(o => o.id === ad.targetId);
        if (item) setSelectedOffer(item);
      } else if (ad.targetType === 'doctor') {
        const item = doctors.find(d => d.id === ad.targetId);
        if (item) setSelectedDoctor(item);
      } else if (ad.targetType === 'taxi') {
        const item = taxis.find(t => t.id === ad.targetId);
        if (item) setSelectedTaxi(item);
      }
    } else if (ad.type === 'text') {
      setSelectedBannerText(ad);
    }
  };

  return (
    <div className="min-h-screen bg-shirqat-bg text-slate-900 font-sans">
      
      {/* --- Splash Screen --- */}
      <AnimatePresence>
        {showSplash && (
          <motion.div 
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-shirqat-primary flex flex-col items-center justify-center text-white"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white p-5 rounded-3xl shadow-2xl mb-4"
            >
              <MapPin size={60} className="text-shirqat-primary" />
            </motion.div>
            <h1 className="text-3xl font-bold mb-1">دليل الشرقاط</h1>
            <p className="text-sky-100 text-sm">كل ما تحتاجه في مدينتك</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Sidebar --- */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="fixed top-0 right-0 bottom-0 z-[70] w-64 bg-white shadow-2xl p-6 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-lg font-bold text-shirqat-primary">القائمة</h2>
                <button onClick={() => setIsSidebarOpen(false)} className="p-1.5 rounded-full bg-slate-100">
                  <X size={18} />
                </button>
              </div>
              <nav className="space-y-4 flex-1">
                {/* Emergency Section */}
                <div className="bg-red-50 p-5 rounded-[2rem] border border-red-100 text-center space-y-3">
                  <div className="w-12 h-12 bg-red-500 text-white rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-red-500/20">
                    <Phone size={24} />
                  </div>
                  <div>
                    <p className="text-xs text-red-600 font-bold mb-1">في حال حدوث أي طارئ</p>
                    <h3 className="text-2xl font-black text-red-700">911</h3>
                  </div>
                  <a 
                    href="tel:911"
                    className="flex items-center justify-center gap-2 bg-red-600 text-white py-3 rounded-xl font-bold text-sm shadow-md active:scale-95 transition-transform"
                  >
                    <span>اتصال فوري</span>
                  </a>
                  <p className="text-[10px] text-red-800 font-bold pt-2 border-t border-red-200/50">
                    حفظ الله القوات الأمنية
                  </p>
                </div>

                <div className="my-2 border-t border-slate-100 pt-4"></div>
                
                <SidebarItem 
                  icon={<Info size={18} />} 
                  label="حول التطبيق" 
                  onClick={() => { setSidebarPage('about'); setIsSidebarOpen(false); }}
                />
                <SidebarItem 
                  icon={<ShieldCheck size={18} />} 
                  label="سياسة الخصوصية" 
                  onClick={() => { setSidebarPage('privacy'); setIsSidebarOpen(false); }}
                />
                <SidebarItem 
                  icon={<Mail size={18} />} 
                  label="تواصل معنا" 
                  onClick={() => { setSidebarPage('contact'); setIsSidebarOpen(false); }}
                />
                <div className="my-4 border-t border-slate-100" />
                {!isAdmin ? (
                  <SidebarItem 
                    icon={<Lock size={18} />} 
                    label="تسجيل دخول الإدارة" 
                    onClick={() => { setShowLoginModal(true); setIsSidebarOpen(false); }} 
                  />
                ) : (
                  <SidebarItem 
                    icon={<ShieldCheck size={18} />} 
                    label="لوحة التحكم" 
                    onClick={() => { setSidebarPage('admin'); setIsSidebarOpen(false); }} 
                  />
                )}
              </nav>
              <div className="pt-4 border-t border-slate-100">
                <p className="text-[10px] text-slate-400 text-center">دليل الشرقاط v2.0</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- Login Modal --- */}
      <AnimatePresence>
        {showLoginModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLoginModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm bg-white rounded-[2.5rem] p-8 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 right-0 h-2 bg-shirqat-primary" />
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-shirqat-primary/10 text-shirqat-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Lock size={32} />
                </div>
                <h2 className="text-xl font-black text-slate-800">تسجيل دخول الإدارة</h2>
                <p className="text-sm text-slate-500 mt-1">يرجى إدخال كلمة المرور للمتابعة</p>
              </div>
              
              <div className="space-y-4">
                <input 
                  type="password" 
                  placeholder="كلمة المرور"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-center text-lg focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                  autoFocus
                />
                <button 
                  onClick={handleLogin}
                  className="w-full bg-shirqat-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-shirqat-primary/20 active:scale-95 transition-transform"
                >
                  دخول
                </button>
                <button 
                  onClick={() => setShowLoginModal(false)}
                  className="w-full text-slate-400 font-bold text-sm py-2"
                >
                  إلغاء
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- Notification Popup --- */}
      <AnimatePresence>
        {activePopupNotification && (
          <motion.div 
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 20 }}
            exit={{ opacity: 0, y: -100 }}
            className="fixed top-0 left-4 right-4 z-[130] max-w-md mx-auto"
          >
            <div className="bg-white rounded-3xl shadow-2xl border border-slate-100 p-4 flex gap-4 items-start">
              <div className="w-10 h-10 rounded-xl bg-orange-500 text-white flex items-center justify-center flex-shrink-0">
                <Bell size={20} />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-800 text-sm">{activePopupNotification.title}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{activePopupNotification.message}</p>
              </div>
              <button 
                onClick={() => setActivePopupNotification(null)}
                className="text-slate-300 hover:text-slate-500"
              >
                <X size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showAdModal && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl text-center"
            >
              <div className="bg-sky-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6 text-shirqat-primary">
                <ShoppingBag size={32} />
              </div>
              <h3 className="text-xl font-bold mb-3">أعلن معنا</h3>
              <p className="text-slate-600 text-sm mb-6 leading-relaxed">
                هل تمتلك محلاً تجارياً في الشرقاط؟ انضم إلينا الآن واعرض عروضك لآلاف المستخدمين يومياً وزد من مبيعاتك.
              </p>
              <a 
                href="https://wa.me/9647740100909"
                className="flex items-center justify-center gap-2 bg-green-500 text-white py-3.5 rounded-2xl font-bold mb-4 shadow-lg shadow-green-500/30"
              >
                <MessageCircle size={20} />
                <span>واتساب: 07740100909</span>
              </a>
              <button 
                onClick={() => setShowAdModal(false)}
                className="text-slate-400 text-sm font-semibold hover:text-slate-600"
              >
                إغلاق النافذة
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- Sidebar Informational Pages --- */}
      <AnimatePresence>
        {selectedBannerText && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedBannerText(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-[2.5rem] w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
            >
              <div className="relative h-48 shrink-0">
                <img src={selectedBannerText.image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <button 
                  onClick={() => setSelectedBannerText(null)}
                  className="absolute top-4 right-4 p-2 bg-black/20 backdrop-blur-md text-white rounded-full"
                >
                  <X size={20} />
                </button>
              </div>
              <div className="p-8 overflow-y-auto">
                <h2 className="text-2xl font-black text-slate-800 mb-4">{selectedBannerText.title}</h2>
                <div className="w-12 h-1 bg-shirqat-primary rounded-full mb-6" />
                <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">
                  {selectedBannerText.content}
                </p>
              </div>
              <div className="p-6 bg-slate-50 border-t border-slate-100">
                <button 
                  onClick={() => {
                    if (selectedBannerText.url) {
                      window.open(selectedBannerText.url, '_blank');
                    }
                    setSelectedBannerText(null);
                  }}
                  className="w-full bg-shirqat-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-shirqat-primary/20 active:scale-95 transition-all"
                >
                  {selectedBannerText.buttonText || 'إغلاق'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- Sidebar Informational Pages --- */}
      <AnimatePresence>
        {sidebarPage && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed inset-0 z-[120] bg-white overflow-y-auto"
          >
            <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 px-4 py-3 flex items-center gap-4">
              <button onClick={() => setSidebarPage(null)} className="p-2 rounded-full bg-slate-50 text-slate-600">
                <ArrowRight size={22} />
              </button>
              <h1 className="text-lg font-bold">
                {sidebarPage === 'about' ? 'حول التطبيق' : 
                 sidebarPage === 'privacy' ? 'سياسة الخصوصية' : 'تواصل معنا'}
              </h1>
            </header>
            
            <div className="p-6">
              {sidebarPage === 'about' && (
                <div className="space-y-6">
                  <div className="bg-sky-50 p-8 rounded-[3rem] text-center border border-sky-100">
                    <div className="bg-white w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                      <MapPin size={40} className="text-shirqat-primary" />
                    </div>
                    <h2 className="text-2xl font-black text-shirqat-primary mb-2">دليل الشرقاط</h2>
                    <p className="text-slate-500 text-sm">الإصدار 2.0.0</p>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-slate-800">عن المنصة</h3>
                    <p className="text-slate-600 leading-relaxed text-sm">
                      دليل الشرقاط هو التطبيق الرسمي الأول والوحيد المخصص لخدمة أهالي قضاء الشرقاط والمناطق المحيطة بها. تم تطويره ليكون جسراً يربط بين المواطن والخدمات الأساسية والتجارية في المدينة.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-bold text-slate-800">مميزات التطبيق</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3 text-sm text-slate-600">
                        <div className="mt-1 text-shirqat-primary"><Tag size={16} /></div>
                        <p><span className="font-bold text-slate-800">تحديثات يومية:</span> نضمن وصول أحدث العروض والمنتجات في دليل الشرقاط فور صدورها.</p>
                      </li>
                      <li className="flex items-start gap-3 text-sm text-slate-600">
                        <div className="mt-1 text-shirqat-primary"><Stethoscope size={16} /></div>
                        <p><span className="font-bold text-slate-800">دليل طبي موثوق:</span> معلومات دقيقة عن الأطباء، التخصصات، وأوقات الدوام مع إمكانية الاتصال المباشر.</p>
                      </li>
                      <li className="flex items-start gap-3 text-sm text-slate-600">
                        <div className="mt-1 text-shirqat-primary"><Car size={16} /></div>
                        <p><span className="font-bold text-slate-800">خدمات النقل:</span> قاعدة بيانات واسعة لسائقي التكسي لضمان وصولك في أي وقت.</p>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                    <h3 className="text-lg font-bold text-slate-800 mb-2">رؤيتنا المستقبلية</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      نطمح لتوسيع الدليل ليشمل كافة المهن والحرف والخدمات الحكومية، لنجعل من "دليل الشرقاط" التطبيق الذي لا يمكن الاستغناء عنه في كل هاتف.
                    </p>
                  </div>
                </div>
              )}
              
              {sidebarPage === 'privacy' && (
                <div className="space-y-6">
                  <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100 flex items-center gap-4">
                    <div className="bg-white p-3 rounded-2xl text-blue-600">
                      <ShieldCheck size={24} />
                    </div>
                    <div>
                      <h3 className="font-bold text-blue-900 text-sm">خصوصيتك هي أولويتنا</h3>
                      <p className="text-[10px] text-blue-700">نحن نلتزم بأعلى معايير حماية البيانات.</p>
                    </div>
                  </div>
                  
                  <div className="space-y-5 text-sm text-slate-600 leading-relaxed">
                    <section>
                      <h4 className="font-bold text-slate-800 mb-2 border-r-4 border-shirqat-primary pr-3">1. المعلومات التي نجمعها</h4>
                      <p>لا يتطلب التطبيق إنشاء حساب أو إدخال بيانات شخصية حساسة. نقوم فقط بجمع بيانات تقنية مجهولة المصدر (مثل نوع الجهاز ونظام التشغيل) لتحسين أداء التطبيق وحل المشكلات التقنية.</p>
                    </section>
                    <section>
                      <h4 className="font-bold text-slate-800 mb-2 border-r-4 border-shirqat-primary pr-3">2. ملفات تعريف الارتباط (Cookies)</h4>
                      <p>نستخدم تقنيات التخزين المحلي لحفظ تفضيلاتك داخل التطبيق، مثل اللغة أو آخر عمليات البحث، لضمان تجربة استخدام أسرع وأكثر سلاسة.</p>
                    </section>
                    <section>
                      <h4 className="font-bold text-slate-800 mb-2 border-r-4 border-shirqat-primary pr-3">3. الروابط الخارجية</h4>
                      <p>قد يحتوي التطبيق على روابط لمواقع خارجية أو تطبيقات تواصل اجتماعي (مثل فيسبوك وواتساب). نحن غير مسؤولين عن سياسات الخصوصية الخاصة بتلك المواقع الخارجية.</p>
                    </section>
                    <section>
                      <h4 className="font-bold text-slate-800 mb-2 border-r-4 border-shirqat-primary pr-3">4. التعديلات على السياسة</h4>
                      <p>نحتفظ بالحق في تحديث سياسة الخصوصية هذه في أي وقت. سيتم إخطار المستخدمين بأي تغييرات جوهرية من خلال إشعارات التطبيق.</p>
                    </section>
                  </div>
                </div>
              )}
              
              {sidebarPage === 'contact' && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-black mb-2">تواصل معنا</h2>
                    <p className="text-slate-500 text-sm">فريقنا جاهز للرد على كافة استفساراتكم</p>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-3">
                    <a href="tel:07740100909" className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 active:scale-95 transition-all">
                      <div className="bg-white p-3 rounded-xl text-shirqat-primary shadow-sm">
                        <Phone size={20} />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">اتصال مباشر</span>
                        <span className="font-bold text-sm">07740100909</span>
                      </div>
                    </a>
                    
                    <a href="https://wa.me/9647740100909" className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 active:scale-95 transition-all">
                      <div className="bg-white p-3 rounded-xl text-green-500 shadow-sm">
                        <MessageCircle size={20} />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">واتساب</span>
                        <span className="font-bold text-sm">مراسلة فورية</span>
                      </div>
                    </a>
                    
                    <a href="mailto:support@shirqat-guide.com" className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 active:scale-95 transition-all">
                      <div className="bg-white p-3 rounded-xl text-blue-500 shadow-sm">
                        <Mail size={20} />
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">الدعم الفني</span>
                        <span className="font-bold text-sm">support@shirqat-guide.com</span>
                      </div>
                    </a>
                  </div>

                  <div className="pt-4">
                    <h3 className="font-bold text-slate-800 mb-4 text-center">تابعنا على منصات التواصل</h3>
                    <div className="flex justify-center gap-4">
                      <a href="#" className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all">
                        <Facebook size={24} />
                      </a>
                      <a href="#" className="w-12 h-12 bg-pink-600 text-white rounded-full flex items-center justify-center shadow-lg active:scale-90 transition-all">
                        <Instagram size={24} />
                      </a>
                    </div>
                  </div>
                  
                  <div className="bg-shirqat-primary/5 p-6 rounded-[2rem] border border-shirqat-primary/10 mt-4">
                    <h4 className="font-bold text-shirqat-primary mb-2 text-sm">مكتبنا الرئيسي</h4>
                    <p className="text-xs text-slate-600 leading-relaxed flex items-start gap-2">
                      <MapPin size={14} className="mt-0.5 shrink-0" />
                      <span>صلاح الدين - قضاء الشرقاط - السوق العام - مجمع النور التجاري</span>
                    </p>
                  </div>
                </div>
              )}

              {sidebarPage === 'admin' && isAdmin && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      {adminView !== 'main' && (
                        <button onClick={() => { setAdminView('main'); setEditingItem(null); }} className="p-2 rounded-xl bg-slate-100 text-slate-600">
                          <ArrowRight size={20} />
                        </button>
                      )}
                      <h2 className="text-2xl font-black text-slate-800">
                        {adminView === 'main' ? 'لوحة التحكم' : 
                         adminView === 'offers' ? 'إدارة السوق' :
                         adminView === 'doctors' ? 'إدارة الأطباء' : 
                         adminView === 'banners' ? 'إدارة البنرات' : 'إدارة التكسي'}
                      </h2>
                    </div>
                    <button 
                      onClick={handleLogout}
                      className="flex items-center gap-2 text-red-500 font-bold text-sm bg-red-50 px-4 py-2 rounded-xl"
                    >
                      <LogOut size={18} />
                      <span>خروج</span>
                    </button>
                  </div>

                  {adminView === 'main' ? (
                    <div className="grid grid-cols-1 gap-6">
                      {/* Quick Actions */}
                      <div className="grid grid-cols-1 gap-3">
                        <button 
                          onClick={() => setAdminView('offers')}
                          className="flex items-center justify-between p-5 bg-white rounded-3xl border border-slate-100 shadow-sm active:scale-95 transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-orange-50 text-orange-500 rounded-2xl flex items-center justify-center">
                              <Tag size={24} />
                            </div>
                            <div className="text-right">
                              <h4 className="font-black text-slate-800">إدارة دليل الشرقاط</h4>
                              <p className="text-xs text-slate-400">إضافة وتعديل العروض والمحلات</p>
                            </div>
                          </div>
                          <ChevronRight size={20} className="text-slate-300" />
                        </button>

                        <button 
                          onClick={() => setAdminView('doctors')}
                          className="flex items-center justify-between p-5 bg-white rounded-3xl border border-slate-100 shadow-sm active:scale-95 transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center">
                              <Stethoscope size={24} />
                            </div>
                            <div className="text-right">
                              <h4 className="font-black text-slate-800">إدارة دليل الأطباء</h4>
                              <p className="text-xs text-slate-400">إضافة وتعديل بيانات الأطباء</p>
                            </div>
                          </div>
                          <ChevronRight size={20} className="text-slate-300" />
                        </button>

                        <button 
                          onClick={() => setAdminView('banners')}
                          className="flex items-center justify-between p-5 bg-white rounded-3xl border border-slate-100 shadow-sm active:scale-95 transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-purple-50 text-purple-500 rounded-2xl flex items-center justify-center">
                              <ShoppingBag size={24} />
                            </div>
                            <div className="text-right">
                              <h4 className="font-black text-slate-800">إدارة البنرات الإعلانية</h4>
                              <p className="text-xs text-slate-400">إدارة الإعلانات المتحركة في الرئيسية</p>
                            </div>
                          </div>
                          <ChevronRight size={20} className="text-slate-300" />
                        </button>

                        <button 
                          onClick={() => setAdminView('taxis')}
                          className="flex items-center justify-between p-5 bg-white rounded-3xl border border-slate-100 shadow-sm active:scale-95 transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-yellow-50 text-yellow-500 rounded-2xl flex items-center justify-center">
                              <Car size={24} />
                            </div>
                            <div className="text-right">
                              <h4 className="font-black text-slate-800">إدارة دليل التكسي</h4>
                              <p className="text-xs text-slate-400">إضافة وتعديل بيانات السواق</p>
                            </div>
                          </div>
                          <ChevronRight size={20} className="text-slate-300" />
                        </button>
                      </div>

                      {/* Data Management */}
                      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                          <Download size={20} className="text-blue-500" />
                          <span>إدارة البيانات (JSON)</span>
                        </h3>
                        <div className="flex flex-wrap gap-3">
                          <button 
                            onClick={exportData}
                            className="flex-1 flex items-center justify-center gap-2 bg-blue-500 text-white py-3 rounded-xl font-bold text-sm"
                          >
                            <Download size={18} />
                            <span>تصدير</span>
                          </button>
                          <label className="flex-1 flex items-center justify-center gap-2 bg-slate-100 text-slate-700 py-3 rounded-xl font-bold text-sm cursor-pointer">
                            <Upload size={18} />
                            <span>استيراد</span>
                            <input type="file" accept=".json" onChange={importData} className="hidden" />
                          </label>
                        </div>
                      </div>

                      {/* Notifications System */}
                      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                          <Bell size={20} className="text-orange-500" />
                          <span>نظام الإشعارات</span>
                        </h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1">عنوان الإشعار</label>
                            <input 
                              id="notif-title"
                              type="text" 
                              placeholder="مثلاً: عرض جديد!" 
                              className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-bold text-slate-500 mb-1">محتوى الإشعار</label>
                            <textarea 
                              id="notif-message"
                              placeholder="اكتب تفاصيل الإشعار هنا..." 
                              rows={3}
                              className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20"
                            ></textarea>
                          </div>
                          <button 
                            onClick={() => {
                              const title = (document.getElementById('notif-title') as HTMLInputElement).value;
                              const message = (document.getElementById('notif-message') as HTMLTextAreaElement).value;
                              if (title && message) {
                                sendNotification(title, message);
                                (document.getElementById('notif-title') as HTMLInputElement).value = '';
                                (document.getElementById('notif-message') as HTMLTextAreaElement).value = '';
                                alert('تم إرسال الإشعار بنجاح');
                              } else {
                                alert('يرجى ملء جميع الحقول');
                              }
                            }}
                            className="w-full flex items-center justify-center gap-2 bg-orange-500 text-white py-3 rounded-xl font-bold text-sm"
                          >
                            <Send size={18} />
                            <span>إرسال إشعار للجميع</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {/* List and Form for Entities */}
                      {adminView === 'offers' && (
                        <AdminEntityManager 
                          items={offers} 
                          setItems={setOffers} 
                          editingItem={editingItem} 
                          setEditingItem={setEditingItem}
                          fields={[
                            { key: 'title', label: 'العنوان', type: 'text' },
                            { key: 'shopName', label: 'اسم المحل', type: 'text' },
                            { key: 'description', label: 'الوصف', type: 'textarea' },
                            { key: 'location', label: 'الموقع', type: 'text' },
                            { key: 'hours', label: 'أوقات العمل', type: 'text' },
                            { key: 'phone1', label: 'رقم الهاتف', type: 'text' },
                            { key: 'image', label: 'رابط الصورة', type: 'text' },
                            { key: 'isRestaurant', label: 'هل هو مطعم؟', type: 'checkbox' },
                            { key: 'isVerified', label: 'موثق؟', type: 'checkbox' },
                          ]}
                        />
                      )}
                      {adminView === 'doctors' && (
                        <AdminEntityManager 
                          items={doctors} 
                          setItems={setDoctors} 
                          editingItem={editingItem} 
                          setEditingItem={setEditingItem}
                          fields={[
                            { key: 'name', label: 'اسم الطبيب', type: 'text' },
                            { key: 'specialty', label: 'التخصص', type: 'text' },
                            { key: 'description', label: 'الوصف', type: 'textarea' },
                            { key: 'location', label: 'الموقع', type: 'text' },
                            { key: 'hours', label: 'أوقات الدوام', type: 'text' },
                            { key: 'phone1', label: 'رقم الهاتف', type: 'text' },
                            { key: 'image', label: 'رابط الصورة', type: 'text' },
                            { key: 'isVerified', label: 'موثق؟', type: 'checkbox' },
                          ]}
                        />
                      )}
                      {adminView === 'banners' && (
                        <AdminEntityManager 
                          items={banners} 
                          setItems={setBanners} 
                          editingItem={editingItem} 
                          setEditingItem={setEditingItem}
                          contextData={{ offers, doctors, taxis }}
                          fields={[
                            { key: 'image', label: 'رابط الصورة الرئيسية للبنر', type: 'text' },
                            { 
                              key: 'type', 
                              label: 'نوع البنر', 
                              type: 'select', 
                              options: [
                                { value: 'internal', label: 'بطاقة داخلية (طبيب/محل/تكسي)' },
                                { value: 'text', label: 'محتوى نصي (منشور)' }
                              ] 
                            },
                            { 
                              key: 'bannerTarget', 
                              label: 'تحديد البطاقة المستهدفة', 
                              type: 'banner-selector',
                              dependsOn: 'type',
                              showIf: 'internal'
                            },
                            { key: 'title', label: 'عنوان المنشور', type: 'text', dependsOn: 'type', showIf: 'text' },
                            { key: 'content', label: 'وصف المنشور', type: 'textarea', dependsOn: 'type', showIf: 'text' },
                            { key: 'buttonText', label: 'نص الزر (مثلاً: اطلب الآن)', type: 'text', dependsOn: 'type', showIf: 'text' },
                            { key: 'url', label: 'رابط خارجي للزر (اختياري)', type: 'text', dependsOn: 'type', showIf: 'text' },
                          ]}
                        />
                      )}
                      {adminView === 'taxis' && (
                        <AdminEntityManager 
                          items={taxis} 
                          setItems={setTaxis} 
                          editingItem={editingItem} 
                          setEditingItem={setEditingItem}
                          fields={[
                            { key: 'name', label: 'اسم السائق / المكتب', type: 'text' },
                            { key: 'carType', label: 'نوع السيارة', type: 'text' },
                            { key: 'description', label: 'الوصف', type: 'textarea' },
                            { key: 'location', label: 'منطقة العمل', type: 'text' },
                            { key: 'hours', label: 'أوقات العمل', type: 'text' },
                            { key: 'phone1', label: 'رقم الهاتف', type: 'text' },
                            { key: 'image', label: 'رابط الصورة', type: 'text' },
                            { key: 'isVerified', label: 'موثق؟', type: 'checkbox' },
                          ]}
                        />
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- Main Navigation View --- */}
      <AnimatePresence mode="wait">
        {!selectedOffer && !selectedDoctor && !selectedTaxi ? (
          <motion.div 
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, x: -20 }}
            className="pb-24"
          >
            {/* --- Header --- */}
            <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {currentTab === 'home' ? (
                  <button onClick={() => setIsSidebarOpen(true)} className="p-2 rounded-lg bg-slate-50 text-slate-600">
                    <Menu size={22} />
                  </button>
                ) : (
                  <button onClick={() => { setCurrentTab('home'); setSearchQuery(''); }} className="p-2 rounded-lg bg-slate-50 text-slate-600">
                    <ArrowRight size={22} />
                  </button>
                )}
                <h1 className="text-lg font-bold text-shirqat-primary">
                  {currentTab === 'home' ? 'دليل الشرقاط' : 
                   currentTab === 'offers' ? 'دليل الشرقاط' :
                   currentTab === 'doctors' ? 'دليل الأطباء' :
                   currentTab === 'taxi' ? 'دليل التكسي' : 'دليل الشرقاط'}
                </h1>
              </div>
              
              <div className="flex items-center gap-2">
                {isSyncing && (
                  <div className="bg-blue-50 text-blue-600 px-2 py-1 rounded-full text-[10px] flex items-center gap-1 font-bold">
                    <motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="inline-block">↻</motion.span>
                    <span>جاري التحديث</span>
                  </div>
                )}
                {justSynced && !isSyncing && (
                  <div className="bg-green-50 text-green-600 px-2 py-1 rounded-full text-[10px] flex items-center gap-1 font-bold">
                    <span>✓</span>
                    <span>تم التحديث</span>
                  </div>
                )}
                {isOffline && !isSyncing && (
                  <div
                    onClick={syncNow}
                    title={lastSync ? `آخر تحديث: ${lastSync.toLocaleTimeString('ar')}` : 'لم تتم المزامنة بعد'}
                    className="bg-amber-50 text-amber-600 px-2 py-1 rounded-full text-[10px] flex items-center gap-1 font-bold cursor-pointer active:scale-95 transition-transform"
                  >
                    <WifiOff size={12} />
                    <span>أوفلاين</span>
                  </div>
                )}
                <button 
                  ref={bellRef}
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 rounded-full bg-slate-50 text-slate-600 relative"
                >
                  <Bell size={20} />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full border-2 border-white flex items-center justify-center px-1">
                      {unreadCount}
                    </span>
                  )}
                </button>
              </div>
            </header>

            {/* --- Notifications Dropdown --- */}
            <AnimatePresence>
              {showNotifications && (
                <motion.div 
                  ref={notificationsRef}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-16 left-4 right-4 z-[55] bg-white rounded-2xl shadow-2xl border border-slate-100 p-4 max-w-md mx-auto"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-sm">الإشعارات</h3>
                    <button onClick={markAllAsRead} className="text-[10px] text-shirqat-primary font-bold">مسح الكل</button>
                  </div>
                  <div className="space-y-3 max-h-[60vh] overflow-y-auto">
                    {notifications.length === 0 ? (
                      <p className="text-center text-slate-400 text-xs py-4">لا توجد إشعارات جديدة</p>
                    ) : (
                      notifications.map(n => (
                        <div 
                          key={n.id} 
                          onClick={() => handleNotificationClick(n.id)}
                          className="p-3 rounded-xl cursor-pointer transition-colors bg-sky-50 border-r-4 border-shirqat-primary"
                        >
                          <h4 className="text-xs font-bold mb-1">{n.title}</h4>
                          <p className="text-[10px] text-slate-500">{n.message}</p>
                          <span className="text-[9px] text-slate-400 mt-2 block">{n.time}</span>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* --- Tab Content --- */}
            {currentTab === 'home' && (
              <>
                <div className="p-6 pt-4">
                {/* --- Banner Ads --- */}
                {banners.length > 0 && (
                  <div className="mb-6">
                    <div className="relative h-44 rounded-[2.5rem] overflow-hidden shadow-xl border border-white/20 bg-slate-900">
                      {banners.map((ad, index) => (
                        <motion.div 
                          key={ad.id}
                          onClick={() => handleBannerClick(ad)}
                          initial={{ opacity: 0 }}
                          animate={{ 
                            opacity: index === currentBanner ? 1 : 0,
                            pointerEvents: index === currentBanner ? 'auto' : 'none'
                          }}
                          transition={{ duration: 0.8 }}
                          className="absolute inset-0 cursor-pointer"
                        >
                          <img src={ad.image} alt="Ad" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                          {ad.type === 'text' && (
                            <div className="absolute bottom-4 right-6 left-6">
                              <h3 className="text-white font-black text-sm drop-shadow-md">{ad.title}</h3>
                            </div>
                          )}
                        </motion.div>
                      ))}
                      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                        {banners.map((_, i) => (
                          <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${i === currentBanner ? 'bg-white w-4' : 'bg-white/40'}`} />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <DashboardCard 
                      icon={<Stethoscope size={28} />} 
                      title="دليل الأطباء" 
                      description="دليل شامل لأطباء وعيادات الشرقاط"
                      onClick={() => setCurrentTab('doctors')}
                      color="bg-medical-blue/10 text-medical-blue"
                      variant="large"
                    />
                  </div>
                  <DashboardCard 
                    icon={<Tag size={24} />} 
                    title="دليل الشرقاط" 
                    description="أحدث العروض والمنتجات"
                    onClick={() => setCurrentTab('offers')}
                    color="bg-offer-orange/10 text-offer-orange"
                  />
                  <DashboardCard 
                    icon={<Car size={24} />} 
                    title="دليل التكسي" 
                    description="أرقام هواتف سواق التكسي"
                    onClick={() => setCurrentTab('taxi')}
                    color="bg-taxi-yellow/10 text-taxi-yellow"
                  />
                </div>

                <div className="mt-8 text-center">
                  <button 
                    onClick={() => setShowAdModal(true)}
                    className="inline-flex items-center gap-2 bg-shirqat-primary text-white px-8 py-4 rounded-2xl font-bold shadow-xl shadow-shirqat-primary/20 hover:scale-105 transition-transform"
                  >
                    <PlusCircle size={20} />
                    <span>أضف عملك في الدليل</span>
                  </button>
                </div>

                <div className="mt-10 space-y-6">
                  <PrayerTimesWidget />
                </div>
              </div>
              </>
            )}

            {currentTab === 'offers' && (
              <div className="mt-4 px-4 space-y-4">
                <div className="relative mb-6">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="ابحث في دليل الشرقاط (مطاعم، محلات، خدمات)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white border border-slate-100 rounded-2xl py-3.5 pr-12 pl-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                  />
                </div>
                {filteredOffers.map(offer => (
                  <div 
                    key={offer.id} 
                    onClick={() => setSelectedOffer(offer)} 
                    className={`bg-white p-4 rounded-3xl shadow-sm border flex gap-4 items-center active:scale-98 transition-transform ${offer.isVerified ? 'border-shirqat-primary/30' : 'border-slate-100'}`}
                  >
                    <img src={offer.image} className="w-16 h-16 rounded-2xl object-cover" referrerPolicy="no-referrer" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h3 className="font-bold text-slate-800 line-clamp-1">{offer.title}</h3>
                      </div>
                      <p className="text-xs text-shirqat-primary font-semibold mb-1">{offer.shopName}</p>
                      <div className="flex items-center gap-1 text-[10px] text-slate-400">
                        <MapPin size={10} />
                        <span className="truncate max-w-[150px]">{offer.location}</span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                ))}
              </div>
            )}

            {currentTab === 'doctors' && (
              <div className="mt-4 px-4 space-y-4">
                <div className="relative mb-6">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="ابحث عن طبيب أو تخصص..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white border border-slate-100 rounded-2xl py-3.5 pr-12 pl-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                  />
                </div>
                {filteredDoctors.map(doc => (
                  <div 
                    key={doc.id} 
                    onClick={() => setSelectedDoctor(doc)} 
                    className={`bg-white p-4 rounded-3xl shadow-sm border flex gap-4 items-center active:scale-98 transition-transform ${doc.isVerified ? 'border-shirqat-primary/30' : 'border-slate-100'}`}
                  >
                    <img src={doc.image} className="w-16 h-16 rounded-2xl object-cover" referrerPolicy="no-referrer" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h3 className="font-bold text-slate-800">{doc.name}</h3>
                      </div>
                      <p className="text-xs text-shirqat-primary font-semibold mb-1">{doc.specialty}</p>
                      <div className="flex items-center gap-1 text-[10px] text-slate-400">
                        <MapPin size={10} />
                        <span className="truncate max-w-[150px]">{doc.location}</span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                ))}
              </div>
            )}

            {currentTab === 'taxi' && (
              <div className="mt-4 px-4 space-y-4">
                <div className="relative mb-6">
                  <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="ابحث عن تكسي أو منطقة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-white border border-slate-100 rounded-2xl py-3.5 pr-12 pl-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                  />
                </div>
                {filteredTaxis.map(taxi => (
                  <div 
                    key={taxi.id} 
                    onClick={() => setSelectedTaxi(taxi)} 
                    className={`bg-white p-4 rounded-3xl shadow-sm border flex gap-4 items-center active:scale-98 transition-transform ${taxi.isVerified ? 'border-shirqat-primary/30' : 'border-slate-100'}`}
                  >
                    <img src={taxi.image} className="w-16 h-16 rounded-2xl object-cover" referrerPolicy="no-referrer" />
                    <div className="flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="font-bold text-slate-800">{taxi.name}</h3>
                    </div>
                    <p className="text-xs text-shirqat-primary font-semibold mb-1">{taxi.carType}</p>
                      <div className="flex items-center gap-1 text-[10px] text-slate-400">
                        <MapPin size={10} />
                        <span className="truncate max-w-[150px]">{taxi.location}</span>
                      </div>
                    </div>
                    <ChevronRight size={18} className="text-slate-300" />
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        ) : (
          /* --- Details Page --- */
          <motion.div 
            key="details"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="min-h-screen bg-white pb-24"
          >
            <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-50 px-4 py-3 flex items-center gap-4">
              <button onClick={() => { setSelectedOffer(null); setSelectedDoctor(null); setSelectedTaxi(null); }} className="p-2 rounded-full bg-slate-50 text-slate-600">
                <ArrowRight size={22} />
              </button>
              <h1 className="text-lg font-bold">التفاصيل</h1>
            </header>

              <div className="p-4">
                {selectedOffer && (
                  <>
                    <img src={selectedOffer.image} className="w-full h-56 object-cover rounded-[2rem] mb-6 shadow-lg" referrerPolicy="no-referrer" />
                    <div className="flex items-center gap-2 text-shirqat-primary font-bold mb-1 text-sm">
                      <ShoppingBag size={16} />
                      <span>{selectedOffer.shopName}</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <h1 className="text-xl font-black leading-tight">{selectedOffer.title}</h1>
                    </div>
                    <div className="bg-shirqat-primary/5 p-5 rounded-3xl mb-6 border border-shirqat-primary/10">
                      <p className="text-slate-700 leading-relaxed text-sm">
                        {selectedOffer.description}
                        {selectedOffer.hours && (
                          <span className="inline-block mr-1 text-shirqat-primary font-bold">
                            (أوقات العمل: {selectedOffer.hours})
                          </span>
                        )}
                      </p>
                    </div>

                    <div className="space-y-3 mb-8">
                      <DetailItem icon={<MapPin size={18} />} label="الموقع" value={selectedOffer.location} />
                      <DetailItem icon={<Phone size={18} />} label="رقم التواصل 1" value={selectedOffer.phone1} isPhone />
                      {selectedOffer.phone2 && <DetailItem icon={<Phone size={18} />} label="رقم التواصل 2" value={selectedOffer.phone2} isPhone />}
                    </div>

                    {selectedOffer.isRestaurant && selectedOffer.menu && (
                      <div className="mb-8">
                        <button 
                          onClick={() => toggleMenu(selectedOffer.id)}
                          className="w-full flex items-center justify-between p-5 rounded-[2rem] bg-shirqat-primary text-white shadow-lg shadow-shirqat-primary/20 active:scale-95 transition-all"
                        >
                          <div className="flex items-center gap-3 font-black">
                            <Utensils size={22} />
                            <span className="text-lg">عرض قائمة الطعام (المنيو)</span>
                          </div>
                          <motion.div
                            animate={{ rotate: expandedMenus[selectedOffer.id] ? 180 : 0 }}
                          >
                            <ChevronRight size={24} />
                          </motion.div>
                        </button>
                        
                        <AnimatePresence>
                          {expandedMenus[selectedOffer.id] && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden"
                            >
                              <div className="space-y-3 mt-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                                {selectedOffer.menu.map((item, idx) => (
                                  <div key={idx} className="flex justify-between items-start gap-4 p-3 rounded-2xl border border-slate-50 bg-slate-50/30">
                                    <div className="flex-1">
                                      <h5 className="text-sm font-bold text-slate-800">{item.name}</h5>
                                      {item.description && <p className="text-[10px] text-slate-500 mt-0.5">{item.description}</p>}
                                    </div>
                                    <span className="text-xs font-black text-shirqat-earth whitespace-nowrap">{item.price}</span>
                                  </div>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    )}

                    {selectedOffer.social && (
                      <div className="mb-8">
                        <h3 className="font-bold text-sm mb-3">روابط التواصل</h3>
                        <div className="grid grid-cols-2 gap-3">
                          {selectedOffer.social.whatsapp && (
                            <a href={`https://wa.me/${selectedOffer.social.whatsapp}`} className="flex items-center justify-center gap-2 bg-green-500 text-white py-3 rounded-xl text-sm font-bold">
                              <MessageCircle size={18} />
                              <span>واتساب</span>
                            </a>
                          )}
                          {selectedOffer.social.facebook && (
                            <a href={selectedOffer.social.facebook} className="flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl text-sm font-bold">
                              <Facebook size={18} />
                              <span>فيسبوك</span>
                            </a>
                          )}
                          {selectedOffer.social.instagram && (
                            <a href={selectedOffer.social.instagram} className="flex items-center justify-center gap-2 bg-pink-600 text-white py-3 rounded-xl text-sm font-bold">
                              <Instagram size={18} />
                              <span>انستقرام</span>
                            </a>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                )}

                {selectedDoctor && (
                  <>
                    <img src={selectedDoctor.image} className="w-full h-56 object-cover rounded-[2rem] mb-6 shadow-lg" referrerPolicy="no-referrer" />
                    <div className="flex items-center gap-2 text-shirqat-primary font-bold mb-1 text-sm">
                      <Stethoscope size={16} />
                      <span>{selectedDoctor.specialty}</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <h1 className="text-xl font-black leading-tight">{selectedDoctor.name}</h1>
                    </div>
                    <div className="bg-shirqat-primary/5 p-5 rounded-3xl mb-6 border border-shirqat-primary/10">
                      <p className="text-slate-700 leading-relaxed text-sm">
                        {selectedDoctor.description}
                        {selectedDoctor.hours && (
                          <span className="inline-block mr-1 text-shirqat-primary font-bold">
                            (أوقات الدوام: {selectedDoctor.hours})
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="space-y-3 mb-8">
                      <DetailItem icon={<MapPin size={18} />} label="الموقع" value={selectedDoctor.location} />
                      <DetailItem icon={<Phone size={18} />} label="رقم التواصل 1" value={selectedDoctor.phone1} isPhone />
                      {selectedDoctor.phone2 && <DetailItem icon={<Phone size={18} />} label="رقم التواصل 2" value={selectedDoctor.phone2} isPhone />}
                    </div>
                  </>
                )}

                {selectedTaxi && (
                  <>
                    <img src={selectedTaxi.image} className="w-full h-56 object-cover rounded-[2rem] mb-6 shadow-lg" referrerPolicy="no-referrer" />
                    <div className="flex items-center gap-2 text-shirqat-primary font-bold mb-1 text-sm">
                      <Car size={16} />
                      <span>{selectedTaxi.carType}</span>
                    </div>
                    <div className="flex items-center justify-between mb-4">
                      <h1 className="text-xl font-black leading-tight">{selectedTaxi.name}</h1>
                    </div>
                    <div className="bg-shirqat-primary/5 p-5 rounded-3xl mb-6 border border-shirqat-primary/10">
                      <p className="text-slate-700 leading-relaxed text-sm">
                        {selectedTaxi.description}
                        {selectedTaxi.hours && (
                          <span className="inline-block mr-1 text-shirqat-primary font-bold">
                            (أوقات العمل: {selectedTaxi.hours})
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="space-y-3 mb-8">
                      <DetailItem icon={<MapPin size={18} />} label="الموقع / منطقة العمل" value={selectedTaxi.location} />
                      <DetailItem icon={<Phone size={18} />} label="رقم التواصل 1" value={selectedTaxi.phone1} isPhone />
                      {selectedTaxi.phone2 && <DetailItem icon={<Phone size={18} />} label="رقم التواصل 2" value={selectedTaxi.phone2} isPhone />}
                    </div>
                  </>
                )}
              </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AdminEntityManager({ items, setItems, editingItem, setEditingItem, fields, contextData }: { items: any[], setItems: any, editingItem: any, setEditingItem: any, fields: any[], contextData?: any }) {
  const [formData, setFormData] = useState<any>(editingItem || {});
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  useEffect(() => {
    setFormData(editingItem || {});
  }, [editingItem]);

  const handleSave = () => {
    if (editingItem && editingItem.id) {
      setItems((prev: any[]) => prev.map(item => item.id === editingItem.id ? formData : item));
    } else {
      const newItem = { ...formData, id: Date.now().toString() };
      setItems((prev: any[]) => [newItem, ...prev]);
    }
    setEditingItem(null);
    setFormData({});
  };

  const confirmDelete = () => {
    if (itemToDelete) {
      setItems((prev: any[]) => prev.filter(item => item.id !== itemToDelete));
      setItemToDelete(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {itemToDelete && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setItemToDelete(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-[2rem] p-8 w-full max-w-sm shadow-2xl text-center"
            >
              <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trash2 size={40} />
              </div>
              <h3 className="text-xl font-black text-slate-800 mb-2">تأكيد الحذف</h3>
              <p className="text-slate-500 text-sm mb-8">هل أنت متأكد من رغبتك في حذف هذه البيانات؟ لا يمكن التراجع عن هذا الإجراء.</p>
              <div className="flex gap-3">
                <button 
                  onClick={confirmDelete}
                  className="flex-1 bg-red-500 text-white py-4 rounded-2xl font-bold shadow-lg shadow-red-500/20 active:scale-95 transition-all"
                >
                  نعم، احذف
                </button>
                <button 
                  onClick={() => setItemToDelete(null)}
                  className="flex-1 bg-slate-100 text-slate-500 py-4 rounded-2xl font-bold active:scale-95 transition-all"
                >
                  إلغاء
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Form Section */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-xl">
        <h3 className="font-black text-lg mb-6 flex items-center gap-2">
          <PlusCircle size={22} className="text-shirqat-primary" />
          <span>{editingItem ? 'تعديل البيانات' : 'إضافة بيانات جديدة'}</span>
        </h3>
        <div className="grid grid-cols-1 gap-4">
          {fields.map(field => {
            if (field.dependsOn && formData[field.dependsOn] !== field.showIf) return null;

            return (
              <div key={field.key}>
                <label className="block text-xs font-bold text-slate-500 mb-1.5 mr-2">{field.label}</label>
                {field.type === 'textarea' ? (
                  <textarea 
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                    rows={3}
                  />
                ) : field.type === 'checkbox' ? (
                  <div className="flex items-center gap-2 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <input 
                      type="checkbox"
                      checked={formData[field.key] || false}
                      onChange={(e) => setFormData({ ...formData, [field.key]: e.target.checked })}
                      className="w-5 h-5 accent-shirqat-primary"
                    />
                    <span className="text-sm font-bold text-slate-700">{field.label}</span>
                  </div>
                ) : field.type === 'select' ? (
                  <select
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20 appearance-none"
                  >
                    <option value="">اختر {field.label}</option>
                    {field.options.map((opt: any) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                ) : field.type === 'banner-selector' ? (
                  <div className="space-y-3">
                    <select
                      value={formData.targetType || ''}
                      onChange={(e) => setFormData({ ...formData, targetType: e.target.value, targetId: '' })}
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20 appearance-none"
                    >
                      <option value="">اختر القسم</option>
                      <option value="offer">دليل الشرقاط (سوق)</option>
                      <option value="doctor">دليل الأطباء</option>
                      <option value="taxi">دليل التكسي</option>
                    </select>
                    {formData.targetType && (
                      <select
                        value={formData.targetId || ''}
                        onChange={(e) => setFormData({ ...formData, targetId: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20 appearance-none"
                      >
                        <option value="">اختر العنصر المحدد</option>
                        {formData.targetType === 'offer' && contextData?.offers.map((o: any) => (
                          <option key={o.id} value={o.id}>{o.title} ({o.shopName})</option>
                        ))}
                        {formData.targetType === 'doctor' && contextData?.doctors.map((d: any) => (
                          <option key={d.id} value={d.id}>{d.name} - {d.specialty}</option>
                        ))}
                        {formData.targetType === 'taxi' && contextData?.taxis.map((t: any) => (
                          <option key={t.id} value={t.id}>{t.name} ({t.carType})</option>
                        ))}
                      </select>
                    )}
                  </div>
                ) : (
                  <input 
                    type="text"
                    value={formData[field.key] || ''}
                    onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-shirqat-primary/20"
                  />
                )}
              </div>
            );
          })}
          <div className="flex gap-3 pt-4">
            <button 
              onClick={handleSave}
              className="flex-1 bg-shirqat-primary text-white py-4 rounded-2xl font-black shadow-lg shadow-shirqat-primary/20 active:scale-95 transition-all"
            >
              حفظ البيانات
            </button>
            {editingItem && (
              <button 
                onClick={() => setEditingItem(null)}
                className="bg-slate-100 text-slate-500 px-6 py-4 rounded-2xl font-bold"
              >
                إلغاء
              </button>
            )}
          </div>
        </div>
      </div>

      {/* List Section */}
      <div className="space-y-3">
        <h3 className="font-black text-lg mr-2">البيانات الحالية</h3>
        {items.map(item => (
          <div key={item.id} className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 overflow-hidden">
              <img src={item.image} className="w-12 h-12 rounded-xl object-cover shrink-0" referrerPolicy="no-referrer" />
              <div className="overflow-hidden">
                <h4 className="font-bold text-sm text-slate-800 truncate">{item.title || item.name}</h4>
                <p className="text-[10px] text-slate-400 truncate">{item.shopName || item.specialty || item.carType}</p>
              </div>
            </div>
            <div className="flex gap-2 shrink-0">
              <button 
                onClick={() => setEditingItem(item)}
                className="p-2.5 rounded-xl bg-blue-50 text-blue-600 active:scale-90 transition-all"
              >
                <PlusCircle size={18} className="rotate-45" />
              </button>
              <button 
                onClick={() => setItemToDelete(item.id)}
                className="p-2.5 rounded-xl bg-red-50 text-red-600 active:scale-90 transition-all"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// --- Helper Components ---

function DashboardCard({ icon, title, description, onClick, color, variant = 'default' }: { icon: any, title: string, description: string, onClick: () => void, color: string, variant?: 'default' | 'large' }) {
  return (
    <button 
      onClick={onClick}
      className={`bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm flex ${variant === 'large' ? 'flex-row' : 'flex-col'} items-center gap-4 text-center active:scale-95 transition-all w-full h-full`}
    >
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${color}`}>
        {icon}
      </div>
      <div className={`flex-1 ${variant === 'large' ? 'text-right' : 'text-center'}`}>
        <h3 className={`${variant === 'large' ? 'text-lg' : 'text-sm'} font-black mb-0.5`}>{title}</h3>
        <p className="text-[10px] text-slate-400 leading-tight">{description}</p>
      </div>
      {variant === 'large' && <ChevronRight size={18} className="text-slate-300" />}
    </button>
  );
}

function SidebarItem({ icon, label, onClick }: { icon: any, label: string, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center gap-3 p-3.5 rounded-xl hover:bg-slate-50 transition-colors text-slate-700"
    >
      <div className="text-shirqat-primary">{icon}</div>
      <span className="text-sm font-bold">{label}</span>
    </button>
  );
}

function DetailItem({ icon, label, value, isPhone }: { icon: any, label: string, value: string, isPhone?: boolean }) {
  return (
    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl">
      <div className="text-shirqat-primary shrink-0">{icon}</div>
      <div className="flex-1">
        <span className="text-[10px] text-slate-400 block mb-0.5">{label}</span>
        <span className="text-sm font-bold text-slate-700">{value}</span>
      </div>
      {isPhone && (
        <a href={`tel:${value}`} className="bg-shirqat-primary text-white px-4 py-1.5 rounded-xl text-xs font-bold shadow-sm shadow-shirqat-primary/20">
          اتصل
        </a>
      )}
    </div>
  );
}
