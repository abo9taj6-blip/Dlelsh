/**
 * useOfflineSync.ts
 * Hook يُدير حالة الاتصال والمزامنة التلقائية
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { DataStorage, shouldSync } from '../services/localDataService';
import { getWeatherData, getPrayerTimes } from '../services/api';

interface SyncStatus {
  isOffline: boolean;
  lastSync: Date | null;
  isSyncing: boolean;
  justSynced: boolean;
}

interface Options {
  onDataRefreshed?: () => void;
}

export function useOfflineSync(options: Options = {}) {
  const [status, setStatus] = useState<SyncStatus>({
    isOffline: !navigator.onLine,
    lastSync: DataStorage.getLastSync() ? new Date(DataStorage.getLastSync()) : null,
    isSyncing: false,
    justSynced: false,
  });
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const sync = useCallback(async (force = false) => {
    if (!navigator.onLine) return;
    if (!force && !shouldSync()) return;
    setStatus(prev => ({ ...prev, isSyncing: true }));
    try {
      await Promise.allSettled([getPrayerTimes(), getWeatherData()]);
      DataStorage.saveLastSync();
      setStatus(prev => ({ ...prev, isSyncing: false, lastSync: new Date(), justSynced: true }));
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => setStatus(prev => ({ ...prev, justSynced: false })), 3000);
      options.onDataRefreshed?.();
    } catch {
      setStatus(prev => ({ ...prev, isSyncing: false }));
    }
  }, [options]);

  useEffect(() => {
    const onOnline  = () => { setStatus(prev => ({ ...prev, isOffline: false })); sync(true); };
    const onOffline = () =>   setStatus(prev => ({ ...prev, isOffline: true }));
    window.addEventListener('online',  onOnline);
    window.addEventListener('offline', onOffline);
    sync(false);
    const interval = setInterval(() => { if (navigator.onLine) sync(false); }, 60 * 60 * 1000);
    return () => {
      window.removeEventListener('online',  onOnline);
      window.removeEventListener('offline', onOffline);
      clearInterval(interval);
      if (timer.current) clearTimeout(timer.current);
    };
  }, [sync]);

  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const handler = (e: MessageEvent) => {
      if (e.data?.type === 'SYNC_COMPLETE' || e.data?.type === 'CACHE_UPDATED') {
        options.onDataRefreshed?.();
      }
    };
    navigator.serviceWorker.addEventListener('message', handler);
    return () => navigator.serviceWorker.removeEventListener('message', handler);
  }, [options]);

  return { ...status, syncNow: () => sync(true) };
}
