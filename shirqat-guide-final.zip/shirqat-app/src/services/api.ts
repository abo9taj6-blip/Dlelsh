/**
 * api.ts — خدمة API مع دعم كامل للعمل بدون إنترنت
 */

import { DataStorage } from './localDataService';

export async function getWeatherData() {
  if (!navigator.onLine) return DataStorage.getWeather();
  try {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=35.5033&longitude=43.2433&current=temperature_2m,weather_code`,
      { signal: AbortSignal.timeout(5000) }
    );
    if (!response.ok) throw new Error('fail');
    const data = await response.json();
    const result = { temp: Math.round(data.current.temperature_2m), code: data.current.weather_code, cachedAt: Date.now() };
    DataStorage.saveWeather(result);
    return result;
  } catch { return DataStorage.getWeather(); }
}

export async function getPrayerTimes() {
  if (!navigator.onLine) { const c = DataStorage.getPrayerTimes(); return c?.timings ?? null; }
  const cached = DataStorage.getPrayerTimes();
  if (cached && isSameDay(cached.cachedAt)) return cached.timings;
  try {
    const response = await fetch(
      `https://api.aladhan.com/v1/timingsByCity?city=Ash%20Sharqat&country=Iraq&method=3`,
      { signal: AbortSignal.timeout(7000) }
    );
    if (!response.ok) throw new Error('fail');
    const data = await response.json();
    const timings = data.data.timings;
    DataStorage.savePrayerTimes({ timings, cachedAt: Date.now() });
    return timings;
  } catch { return cached?.timings ?? null; }
}

function isSameDay(ts: number): boolean {
  const c = new Date(ts), n = new Date();
  return c.getFullYear()===n.getFullYear() && c.getMonth()===n.getMonth() && c.getDate()===n.getDate();
}

export const WEATHER_INTERPRETATION: Record<number, { label: string; icon: string }> = {
  0:{label:'صافي',icon:'Sun'},1:{label:'صافي غالباً',icon:'Sun'},2:{label:'غائم جزئياً',icon:'Cloud'},
  3:{label:'غائم',icon:'Cloud'},45:{label:'ضباب',icon:'Cloud'},48:{label:'ضباب جليدي',icon:'Cloud'},
  51:{label:'رذاذ خفيف',icon:'CloudRain'},61:{label:'مطر خفيف',icon:'CloudRain'},
  71:{label:'ثلج خفيف',icon:'Cloud'},95:{label:'عاصفة رعدية',icon:'Zap'},
};
