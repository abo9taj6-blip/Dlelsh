/**
 * localDataService.ts
 * خدمة إدارة البيانات المحلية عبر localStorage
 */

const KEYS = {
  OFFERS:        'shirqat_offers',
  DOCTORS:       'shirqat_doctors',
  TAXIS:         'shirqat_taxis',
  BANNERS:       'shirqat_banners',
  NOTIFICATIONS: 'shirqat_notifications',
  PRAYER_TIMES:  'shirqat_prayer_times',
  WEATHER:       'shirqat_weather',
  LAST_SYNC:     'shirqat_last_sync',
};

export function saveToStorage<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.warn('[Storage] Failed to save:', key, e);
  }
}

export function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (e) {
    console.warn('[Storage] Failed to load:', key, e);
    return fallback;
  }
}

export const DataStorage = {
  getOffers:  (fallback: any[]) => loadFromStorage(KEYS.OFFERS, fallback),
  saveOffers: (data: any[])     => saveToStorage(KEYS.OFFERS, data),

  getDoctors:  (fallback: any[]) => loadFromStorage(KEYS.DOCTORS, fallback),
  saveDoctors: (data: any[])     => saveToStorage(KEYS.DOCTORS, data),

  getTaxis:  (fallback: any[]) => loadFromStorage(KEYS.TAXIS, fallback),
  saveTaxis: (data: any[])     => saveToStorage(KEYS.TAXIS, data),

  getBanners:  (fallback: any[]) => loadFromStorage(KEYS.BANNERS, fallback),
  saveBanners: (data: any[])     => saveToStorage(KEYS.BANNERS, data),

  getNotifications:  (fallback: any[]) => loadFromStorage(KEYS.NOTIFICATIONS, fallback),
  saveNotifications: (data: any[])     => saveToStorage(KEYS.NOTIFICATIONS, data),

  getPrayerTimes:  () => loadFromStorage<any>(KEYS.PRAYER_TIMES, null),
  savePrayerTimes: (data: any) => saveToStorage(KEYS.PRAYER_TIMES, data),

  getWeather:  () => loadFromStorage<any>(KEYS.WEATHER, null),
  saveWeather: (data: any) => saveToStorage(KEYS.WEATHER, data),

  getLastSync:  () => loadFromStorage<number>(KEYS.LAST_SYNC, 0),
  saveLastSync: () => saveToStorage(KEYS.LAST_SYNC, Date.now()),
};

// تحديث كل 6 ساعات
const SYNC_INTERVAL_MS = 6 * 60 * 60 * 1000;

export function shouldSync(): boolean {
  return Date.now() - DataStorage.getLastSync() > SYNC_INTERVAL_MS;
}
